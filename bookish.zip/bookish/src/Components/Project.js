import React from 'react';
import {Homepage} from '../pages/Homepage';

const Project = () => {
  return (
      <Homepage/>
  );
}

export default Project;
