const genreApi = [{
    id:1,
    Genre:"Fiction",
    Description: "Fiction is any creative work, chiefly any narrative work, portraying individuals, events, or places that are imaginary, or in ways that are imaginary.",
},
{
    id:2,
    Genre:"Thriller",
    Description: "A thriller is a type of mystery with a few key differences.",
},
{
    id:3,
    Genre:"Tech",
    Description: "Technology is the application of scientific knowledge to the practical aims of human life or, as it is sometimes phrased, to the change and manipulation of the human environment.",
},
{
    id:4,
    Genre:"Romance",
    Description: "A romance is a relationship between two people who are in love with each other",
},
{
    id:5,
    Genre:"Philosophy",
    Description: "Philosophy is critical and comprehensive thought, the most critical and comprehensive manner of thinking which the human species has yet devised.",
},];

export default genreApi;